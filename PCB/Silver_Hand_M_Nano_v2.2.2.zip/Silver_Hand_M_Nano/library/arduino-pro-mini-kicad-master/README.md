# arduino-pro-mini-kicad
This is a clone of the well known arduino board "pro-mini" designed in kicad while the original was designed in eagle. Ref https://store.arduino.cc/arduino-pro-mini 
![Screenshot](arduino-pro-mini.png)
![Screenshot](Screenshot3D.png)
